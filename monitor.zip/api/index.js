import videos from "../videos.js";

export default function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Content-Type", "application/json");

  if (req.method !== "GET") {
    return res.status(405).json({
      success: false,
      message: "Method not allowed"
    });
  }

  let count = 1;

  if (req.query.count !== undefined) {
    count = parseInt(req.query.count);
  }

  if (isNaN(count) || count <= 0) {
    return res.status(400).json({
      success: false,
      message: "count must be a positive number"
    });
  }

  const shuffledVideos = [...videos].sort(() => Math.random() - 0.5);
  const selectedVideos = shuffledVideos.slice(
    0,
    Math.min(count, videos.length)
  );

  return res.status(200).json({
    success: true,
    total: selectedVideos.length,
    videos: selectedVideos
  });
}